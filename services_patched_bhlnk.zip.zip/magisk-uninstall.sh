#example magisk uninstall.sh files
